<?= $this->extend('template') ?>

<?= $this->section('main') ?>
<div class="container py-5">
    <!-- Header -->
    <div class="text-center mb-5">
        <h1 class="fw-bold text-primary">Review Pesanan Anda</h1>
        <p class="text-muted">Periksa detail pesanan sebelum menyelesaikan transaksi.</p>
    </div>

    <!-- Order Summary Section -->
    <div class="row gy-4">
        <!-- Order Summary -->
        <div class="col-md-8">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-header bg-light border-bottom-0 rounded-top-4 py-3">
                    <h5 class="mb-0 text-secondary"><i class="fas fa-shopping-cart me-2"></i>Ringkasan Pesanan</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex align-items-center mb-3">
                        <img src="/api/placeholder/80/80" class="rounded me-3" alt="Product Image" style="width: 80px; height: 80px;">
                        <div>
                            <h6 class="mb-1 text-dark">jamal</h6>
                            <p class="fw-bold text-primary mb-0">Rp15.000.000</p>
                        </div>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between">
                        <p class="text-muted mb-0">Subtotal</p>
                        <p class="fw-bold text-dark">Rp15.000.000</p>
                    </div>
                    <div class="d-flex justify-content-between">
                        <p class="text-muted mb-0">Pengiriman</p>
                        <p class="fw-bold text-success">Gratis</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Summary Total -->
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-header bg-light border-bottom-0 rounded-top-4 py-3">
                    <h5 class="mb-0 text-secondary"><i class="fas fa-file-invoice-dollar me-2"></i>Total Pembayaran</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between">
                        <span class="text-muted">Total:</span>
                        <h4 class="text-primary fw-bold mb-0">Rp15.000.000</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Address Section -->
    <div class="card border-0 shadow-sm rounded-4 mt-4">
        <div class="card-header bg-light border-bottom-0 rounded-top-4 py-3">
            <h5 class="mb-0 text-secondary"><i class="fas fa-map-marker-alt me-2"></i>Alamat Pengiriman</h5>
        </div>
        <div class="card-body">
            <div class="d-flex align-items-start">
                <div class="icon-box bg-primary text-white me-3">
                    <i class="fas fa-home"></i>
                </div>
                <div>
                    <h6 class="text-dark fw-bold">Alamat Utama</h6>
                    <p class="text-muted">Jl. Muaro Jambi - Muaro Bulian KM 16, MENDALO</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Payment Method -->
    <div class="card border-0 shadow-sm rounded-4 mt-4">
        <div class="card-header bg-light border-bottom-0 rounded-top-4 py-3">
            <h5 class="mb-0 text-secondary"><i class="fas fa-credit-card me-2"></i>Metode Pembayaran</h5>
        </div>
        <div class="card-body">
            <div class="d-flex align-items-center">
                <div class="icon-box bg-primary text-white me-3">
                    <i class="fas fa-university"></i>
                </div>
                <div>
                    <h6 class="text-dark fw-bold mb-2">Transfer Bank</h6>
                    <div class="badge bg-primary text-white me-2">BRI</div>
                    <span class="text-dark fw-bold">FAIDAN ALHAQIQI</span>
                    <div class="input-group mt-3">
                        <input type="text" value="1122334455" class="form-control bg-light border-0 rounded-start" readonly>
                        <button class="btn btn-primary rounded-end" type="button" onclick="navigator.clipboard.writeText('1122334455')">
                            <i class="fas fa-copy"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Submit Section -->
    <div class="text-center mt-5">
        <form action="<?= base_url('submit') ?>" method="POST">
            <button type="submit" class="btn btn-primary btn-lg px-5 rounded-4 shadow">
                <i class="fas fa-check-circle me-2"></i>Konfirmasi Pesanan
            </button>
        </form>
    </div>
</div>

<style>
    body {
        background-color:rgb(0, 95, 238);
    }

    .card {
        border-radius: 1.25rem;
    }

    .icon-box {
        width: 50px;
        height: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        font-size: 1.5rem;
    }

    .btn-primary {
        background-color:rgb(234, 0, 255);
        border: none;
        transition: background-color 0.3s ease;
    }

    .btn-primary:hover {
        background-color:rgb(255, 0, 34);
    }

    .badge {
        padding: 0.4rem 0.8rem;
        font-size: 0.85rem;
    }

    .input-group .btn {
        background-color:rgb(0, 12, 26);
        border: none;
    }

    .input-group .btn:hover {
        background-color:rgb(255, 238, 0);
    }
</style>
<?= $this->endSection() ?>
