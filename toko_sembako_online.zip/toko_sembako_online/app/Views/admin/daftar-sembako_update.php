<?= $this->extend('admin/template') ?>  
<?= $this->section('main') ?>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Update Data Sembako</h4>
                </div>
                <div class="card-body">
                    <?php if (session()->getFlashdata('error')) : ?>
                        <div class="alert alert-danger">
                            <?= session()->getFlashdata('error') ?>
                        </div>
                    <?php endif; ?>

                    <form action="<?= base_url('admin/daftar-sembako/update/' . $sembako['id']) ?>" method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="nama" class="form-label">Nama </label>
                            <input type="text" class="form-control" id="nama" name="nama" value="<?= $sembako['nama'] ?? '' ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="kategori" class="form-label">kategori</label>
                            <input type="text" class="form-control" id="kategori" name="kategori" value="<?= $sembako['kategori'] ?? '' ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="deskripsi" class="form-label">deskripsi</label>
                            <input type="number" class="form-control" id="deskripsi" name="deskripsi" value="<?= $sembako['deskripsi'] ?? '' ?>" step="0.01" required>
                        </div>

                        <div class="mb-3">
                            <label for="stok" class="form-label">stok</label>
                            <textarea class="form-control" id="stok" name="stok" rows="4" required><?= $sembako['stok'] ?? '' ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="gambar" class="form-label">Gambar</label>
                            <?php if (!empty($sembako['gambar'])) : ?>
                                <div class="mb-2">
                                    <img src="<?= base_url('images/' . $sembako['gambar']) ?>" class="img-thumbnail" width="200px">
                                </div>
                            <?php endif; ?>
                            <input type="file" class="form-control" id="gambar" name="gambar" accept="image/*">
                            <small class="text-muted">Biarkan kosong jika tidak ingin mengubah gambar</small>
                        </div>

                        <div class="mb-3">
                            <label for="harga" class="form-label">Harga</label>
                            <input type="number" class="form-control" id="harga" name="harga" value="<?= $sembako['harga'] ?? '' ?>" required>
                        </div>

                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary">Update Data</button>
                            <a href="<?= base_url('admin/daftar-sembako') ?>" class="btn btn-secondary">Kembali</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
