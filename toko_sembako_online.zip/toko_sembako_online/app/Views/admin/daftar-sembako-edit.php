<?= $this->extend('admin/template') ?>  
<?= $this->section('main') ?>
    <div class="container">
        <h4>Edit Data Sembako</h4>
        <form action="<?= base_url('admin/daftar-sembako/update/' . $sembako['id']) ?>" method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="form-label">Nama </label>
                <input type="text" class="form-control" name="nama" value="<?= $sembako['nama'] ?? '' ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Kategori</label>
                <input type="text" class="form-control" name="kategori" value="<?= $sembako['kategori'] ?? '' ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">deskripsi</label>
                <input type="text" class="form-control" name="deskripsi
                " value="<?= $sembako['deskripsi'] ?? '' ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">stok</label>
                <input type="text" class="form-control" name="stok" value="<?= $sembako['stok'] ?? '' ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Gambar</label>
                <input type="file" class="form-control" name="gambar">
                <?php if (!empty($sembako['gambar'])): ?>
                    <small class="text-muted">Gambar saat ini: <?= $sembako['gambar'] ?></small>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="form-label">Harga</label>
                <input type="number" class="form-control" name="harga" value="<?= $sembako['harga'] ?? '' ?>">
            </div>

            <button type="submit" class="btn btn-primary">Update</button>
            <a href="<?= base_url('admin/daftar-sembako') ?>" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
<?= $this->endSection() ?>
