<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Admin Toko Sembako Online</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="<?= base_url()?>css/style.css">
    <style>
      /* General Styling */
      body {
        font-family: 'Poppins', sans-serif;
        background-color:rgb(245, 202, 9);
        color:rgb(255, 255, 255);
      }

      h2, h5 {
        font-weight: bold;
      }

      .container {
        margin-top: 20px;
      }

      .sidebar {
        background-color:rgb(210, 217, 224);
        color: white;
        padding: 20px;
        border-radius: 12px;
      }

      .sidebar ul {
        list-style: none;
        padding: 0;
      }

      .sidebar ul li a {
        display: flex;
        align-items: center;
        gap: 10px;
        color: white;
        text-decoration: none;
        padding: 10px 15px;
        border-radius: 8px;
        transition: all 0.3s;
      }

      .sidebar ul li a:hover {
        background-color:rgb(22, 98, 175);
        color: #fff;
      }

      .card {
        border: none;
        border-radius: 15px;
        box-shadow: 0 5px 15px rgba(11, 192, 123, 0.1);
        transition: transform 0.3s;
      }

      .card:hover {
        transform: translateY(-5px);
      }

      .icon-box {
        width: 60px;
        height: 60px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        font-size: 1.5rem;
        color: #fff;
      }

      .icon-box.bg-success {
        background-color:rgb(56, 126, 73);
      }

      .icon-box.bg-primary {
        background-color:rgb(255, 94, 220);
      }

      .icon-box.bg-warning {
        background-color:rgb(61, 0, 63);
      }

      footer {
        background-color:rgb(240, 0, 92);
        color: #fff;
        padding: 15px 0;
        text-align: center;
      }
    </style>
  </head>
  <body>
    <!-- Container -->
    <div class="container">
      <!-- Header -->
      <div class="row mb-4 align-items-center">
        <div class="col">
          <h2>Admin Dashboard</h2>
        </div>
        <div class="col text-end">
          <a href="<?= base_url('logout') ?>" class="btn btn-danger">
            <i class="fas fa-sign-out-alt me-1"></i> Logout
          </a>
        </div>
      </div>

      <!-- Main Layout -->
      <div class="row">
        <!-- Sidebar -->
        <div class="col-3 sidebar">
          <h5 class="mb-4">Menu</h5>
          <ul>
            <li>
              <a href="<?= base_url('admin/dashboard') ?>">
                <i class="fas fa-home"></i> Dashboard
              </a>
            </li>
            <li>
              <a href="<?= base_url('admin/daftar-sembako') ?>">
                <i class="fas fa-box"></i> Daftar Sembako
              </a>
            </li>
            <li>
              <a href="<?= base_url('admin/transaksi') ?>">
                <i class="fas fa-shopping-cart"></i> Transaksi
              </a>
            </li>
            <li>
              <a href="<?= base_url('admin/pelanggan') ?>">
                <i class="fas fa-users"></i> Pelanggan
              </a>
            </li>
          </ul>
        </div>

        <!-- Content -->
        <div class="col-9">
          <div class="dashboard-container p-4 bg-white rounded-4 shadow-sm">
            <!-- Dashboard Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
              <h2 class="text-primary fw-bold mb-0">
                <i class="fas fa-tachometer-alt me-2"></i> Dashboard
              </h2>
              <div class="btn-group">
                <button class="btn btn-outline-primary">
                  <i class="fas fa-download me-1"></i> Export
                </button>
                <button class="btn btn-outline-primary">
                  <i class="fas fa-print me-1"></i> Print
                </button>
              </div>
            </div>

            <!-- Stats Section -->
            <div class="row g-4">
              <!-- Revenue Card -->
              <div class="col-md-6">
                <div class="card bg-light">
                  <div class="card-body d-flex align-items-center">
                    <div class="icon-box bg-success me-3">
                      <i class="fas fa-money-bill-wave"></i>
                    </div>
                    <div>
                      <h6>Total Pendapatan</h6>
                      <h4 class="fw-bold text-success">Rp130.000.000</h4>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Transactions Card -->
              <div class="col-md-6">
                <div class="card bg-light">
                  <div class="card-body d-flex align-items-center">
                    <div class="icon-box bg-primary me-3">
                      <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div>
                      <h6>Total Transaksi</h6>
                      <h4 class="fw-bold text-primary">145</h4>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Recent Activity -->
            <div class="mt-5">
              <h5 class="fw-bold mb-3">Aktivitas Terkini</h5>
              <ul class="list-group">
                <li class="list-group-item d-flex align-items-center">
                  <div class="icon-box bg-success me-3">
                    <i class="fas fa-check"></i>
                  </div>
                  <div>
                    <h6 class="mb-1">Transaksi Berhasil</h6>
                    <small class="text-muted">Beras Premium - Rp200.000</small>
                  </div>
                  <small class="ms-auto text-muted">5 menit yang lalu</small>
                </li>
                <li class="list-group-item d-flex align-items-center">
                  <div class="icon-box bg-warning me-3">
                    <i class="fas fa-clock"></i>
                  </div>
                  <div>
                    <h6 class="mb-1">Menunggu Pembayaran</h6>
                    <small class="text-muted">Minyak Goreng - Rp50.000</small>
                  </div>
                  <small class="ms-auto text-muted">15 menit yang lalu</small>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Footer -->
    <footer>
      &copy; 2024 Toko Sembako FAIDAN GAN | Jambi
    </footer>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
