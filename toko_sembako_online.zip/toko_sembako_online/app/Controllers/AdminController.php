<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\SembakoModel;
use CodeIgniter\HTTP\ResponseInterface;

class AdminController extends BaseController 
{
    public function index() 
    {
        return view('admin/dashboard');
    }

    public function daftarSembako() 
    {
        $sembakoModel = new SembakoModel();
        $data['sembako'] = $sembakoModel->findAll();
        return view('admin/daftar-sembako', $data);
    }

    public function daftarSembakoTambah() 
    {
        return view('admin/daftar-sembako-tambah');
    }

    public function createSembako() 
    {
        $data = $this->request->getPost();
        $file = $this->request->getFile('gambar');

        if (!$file->hasMoved()) {
            $path = $file->store('images');
            $data['gambar'] = $path;
        }

        $sembakoModel = new SembakoModel();

        if ($sembakoModel->insert($data, false)) {
            return redirect()->to('admin/daftar-sembako')->with('berhasil', 'Data berhasil disimpan!');
        } else {
            return redirect()->to('admin/daftar-sembako')->with('gagal', 'Data gagal disimpan!');
        }
    }

    public function daftarSembakoEdit($id) 
    {
        $sembakoModel = new SembakoModel();
        $data['sembako'] = $sembakoModel->find($id);
        
        if ($data['sembako']) {
            return view('admin/daftar-sembako-edit', $data);
        }
        return redirect()->to('admin/daftar-sembako')->with('gagal', 'Data Sembako tidak ditemukan.');
    }

    public function updateSembako($id) 
    {
        $sembakoModel = new SembakoModel();
        $data = $this->request->getPost();
        
        // Handle image upload if new image is provided
        $file = $this->request->getFile('gambar');
        if ($file->isValid() && !$file->hasMoved()) {
            $path = $file->store('images');
            $data['gambar'] = $path;
        }

        if ($sembakoModel->update($id, $data)) {
            return redirect()->to('admin/daftar-sembako')->with('berhasil', 'Data Sembako berhasil diupdate!');
        }
        return redirect()->to('admin/daftar-sembako')->with('gagal', 'Data Sembako gagal diupdate!');
    }

    public function daftarSembakoUpdate($id) 
    {
        $sembakoModel = new SembakoModel();
        $data = $this->request->getPost();
        
        // Handle image upload if new image is provided
        $file = $this->request->getFile('gambar');
        if ($file->isValid() && !$file->hasMoved()) {
            $path = $file->store('images');
            $data['gambar'] = $path;
        }
        
        if ($sembakoModel->update($id, $data)) {
            return redirect()->to('admin/daftar-sembako')->with('berhasil', 'Data Sembako berhasil diupdate!');
        }
        return redirect()->to('admin/daftar-sembako')->with('gagal', 'Data Sembako gagal diupdate!');
    }

    public function hapusSembako($id) 
    {
        $sembakoModel = new SembakoModel();
        $sembako = $sembakoModel->find($id);

        if ($sembako) {
            $sembakoModel->delete($id);
            return redirect()->to('/admin/daftar-sembako')->with('berhasil', 'Data Sembako berhasil dihapus.');
        }
        return redirect()->to('/admin/daftar-sembako')->with('gagal', 'Data Sembako tidak ditemukan.');
    }

    public function transaksi() 
    {
        return view('admin/transaksi');
    }

    public function transaksiUbahStatus() 
    {
        return view('admin/transaksi-ubah-status');
    }

    public function transaksiHapus() 
    {
        return view('admin/transaksi-hapus');
    }

    public function pelanggan() 
    {
        return view('admin/pelanggan');
    }

    public function pelangganHapus() 
    {
        return view('admin/pelanggan-hapus');
    }
}
